/**
 * Created by lingweicong on 17-4-25.
 */
$("#submit").click(function () {
    console.log(123)
    $(".popup").css("display","block")
    $(".warpe").css("display","block")
})